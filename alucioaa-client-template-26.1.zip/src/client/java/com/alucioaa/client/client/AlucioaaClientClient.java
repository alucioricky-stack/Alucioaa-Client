package com.alucioaa.client.client;

import net.fabricmc.api.ClientModInitializer;

public class AlucioaaClientClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}